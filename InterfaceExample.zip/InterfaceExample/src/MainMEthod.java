
public class MainMEthod {

	public static void main(String[] args) {
		Summation sm = new SummationImpl();
		sm.greeting();
		
		Summation sm1 = new SummationImpl2();
		sm1.greeting();
		
		Summation sm2 = new SummationImpl3();
		sm2.greeting();
	}
	
//	public void process(accountnumber) {
//		//fetchAccountNumber(int accountNumber)
//		// logic with account number
//		// logic with account number
//		// logic with account number
//		// logic with account number
//		//fetchAccountNumber(int accountNumber)
//		// diff
//		// diff
//		//fetchAccountNumber(int accountNumber)
//		 // return
//	}
//	
//	private int fetchAccountNumber(int accountNumber) {
//		// fetch account number (accountNumber)
//		return;
//	}
}
