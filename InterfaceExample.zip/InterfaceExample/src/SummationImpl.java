
public class SummationImpl implements Summation{

	@Override
	public int sum(int b) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void add(int b) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int sub(int b) {
		// TODO Auto-generated method stub
		return 0;
	}

}
