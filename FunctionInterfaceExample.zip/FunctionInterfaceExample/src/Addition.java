
@FunctionalInterface
public interface Addition {
	public void add(int a, int b);
}
